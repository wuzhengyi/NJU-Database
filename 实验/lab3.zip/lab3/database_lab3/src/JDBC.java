import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//import entity.UserInfo;

public class JDBC {
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    private Statement statement;
    /**
     * connection database
     */
    public Connection getConnection(){
        String url="jdbc:mysql://localhost:3306/lab3?useSSL=false";
        String ssl = "useSSL=false";
        String userName="root";
        String password="wuzhengyi";
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("�Ҳ���������");
            e.printStackTrace();
        }
        try {
            conn=DriverManager.getConnection(url,userName, password);
            if(conn!=null){
//                System.out.println("connection successful");
                statement = conn.createStatement();       //create Statement
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
                System.out.println( "connection fail");
            e.printStackTrace();
        }
        return conn;
    }

    public void closeConnection(){
        try {
            conn.close();
        }catch(SQLException e) {
            e.printStackTrace();
        }

    }

    public ResultSet querySql(String sql) {
        ResultSet result = null;

        try
        {
            result = statement.executeQuery(sql);
        } catch (SQLException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return result;
    }

    public static void printStaff(ResultSet result) {
        try
        {
            while(result.next()) {
                System.out.println("SNAME:" + result.getString(1)
                        + " SNO:" + result.getString(2)
                        + " AGE:" + result.getString(3)
                        + " SALARY:" + result.getString(4)
                        + " DNO:" + result.getString(5)
                );
            }
        } catch (SQLException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public void executeSql(String sql) {
        try
        {
            statement.execute(sql);
        } catch (SQLException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void testJDBC(){
        System.out.println("\n Create Staff Table:");
        executeSql("CREATE TABLE Staff\n" +
                "(\n" +
                "    SNAME char(8) NOT NULL,\n" +
                "    SNO int NOT NULL,\n" +
                "    AGE int DEFAULT 0, -- Ĭ��ֵԼ��\n" +
                "    SALARY int,\n" +
                "    DNO int, -- FOREIGN KEY REFERENCES Department(DNO) --���Լ����֮���ټ�\n" +
                "    PRIMARY KEY (SNO)\n" +
                ");");
        String sql = "SELECT * FROM Staff;";
        ResultSet result = querySql(sql);//�ڿ���̨�@ʾ�����ҷ���
        printStaff(result);

        System.out.println("\n Insert to Staff Table:");
        executeSql("INSERT INTO Staff\n" +
                "VALUES \n" +
                "('л����',131,21,-5,1),\n" +
                "('������',129,20,1000,2),\n" +
                "('������',130,21,100,3);");
        sql = "SELECT * FROM Staff;";
        result = querySql(sql);//�ڿ���̨�@ʾ�����ҷ���
        printStaff(result);

        System.out.println("\n��Staff���в�������:");
        executeSql("INSERT INTO Staff(SNAME,SNO,AGE,DNO)\n" +
                "VALUES\n" +
                "('��һ�',128,21,3),\n" +
                "('������',133,21,2);");
        sql = "SELECT * FROM Staff;";
        result = querySql(sql);//�ڿ���̨�@ʾ�����ҷ���
        printStaff(result);

        System.out.println("\n��ʾStaff����������:");
        sql = "SELECT * FROM Staff;";
        result = querySql(sql);//�ڿ���̨�@ʾ�����ҷ���
        printStaff(result);

        System.out.println("\nɾ��SNOΪ128����һ�:");
        executeSql("DELETE FROM Staff WHERE SNO = 128;");
        result = querySql(sql);
        printStaff(result);

        System.out.println("\n����('��һ�',128,21,3):");
        executeSql("INSERT INTO Staff(SNAME,SNO,AGE,DNO) VALUES ('��һ�',128,21,3);");
        result = querySql(sql);
        printStaff(result);

        System.out.println("\n����('������',110,1,100000,2):");
        executeSql("INSERT INTO Staff VALUES ('������',110,1,100000,2);");
        result = querySql(sql);
        printStaff(result);

        System.out.println("\n��SNO=129�ĸ�Ϊ127:");
        executeSql("update Staff set SNO = 127 where SNO=129;");
        result = querySql(sql);
        printStaff(result);
        System.out.println();
    }

//    public static void main(String[] args) {
//        JDBC j=new JDBC();
//        j.getConnection();
//        j.teztJDBC();
//
//        try{
//            DBCP d = new DBCP();
//            d.getParameter();
//            d.testDBCP();
//        }
//        catch (SQLException e)
//        {
//            e.printStackTrace();
//        }
//    }

}